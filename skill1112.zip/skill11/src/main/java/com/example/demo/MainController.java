package com.example.demo;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	@Autowired
	private StudentService sservice;
	
	@Autowired
	private StudentRepo srepo;
	
	@RequestMapping("/students")
	private ResponseEntity<Object> Students(){
		
		return new ResponseEntity<>(this.srepo.findAll(), HttpStatus.OK);
	}
	
	@RequestMapping("/student/{id}")
	private ResponseEntity<Object> AddHotel(@PathVariable("id") int id){
		return new ResponseEntity<>(this.srepo.findById(id), HttpStatus.OK);
	}
	
	@PostMapping("/addStudent")
	private ResponseEntity<Object> AddFood(@RequestBody Student studnet){
		this.srepo.save(studnet);
		return new ResponseEntity<>("Studnet added successfully", HttpStatus.CREATED);
	}
	
	@PutMapping("/updateStudent/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable("id") int id, @RequestBody Student student) {
		Optional<Student> sData = srepo.findById(id);

		if (sData.isPresent()) {
			Student st = sData.get();
			st.setFname(student.getFname());
			st.setAddress(student.getAddress());
			st.setHackathonname(student.getHackathonname());
			return new ResponseEntity<>(srepo.save(st), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	
	@DeleteMapping("/deleteStudent/{id}")
	public ResponseEntity<Object> deleteStudent(@PathVariable("id") int id) {
		try {
			srepo.deleteById(id);
			return new ResponseEntity<>("Delete successfull",HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}