package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	@GeneratedValue
	private int sid;
	private String fname;
	private String address;
	private String hackathonname;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getHackathonname() {
		return hackathonname;
	}
	public void setHackathonname(String hackathonname) {
		this.hackathonname = hackathonname;
	}
	public Student(int sid, String fname, String address, String hackathonname) {
		super();
		this.sid = sid;
		this.fname = fname;
		this.address = address;
		this.hackathonname = hackathonname;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
